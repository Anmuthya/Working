#!/bin/sh
read -p "Enter your username to be used on the server !!! -  " USAR
PAWD="" 

prompt=" > Input your password :"
                while IFS= read -p "$prompt" -r -s -n 1 char ;do
                        [[ $char == $'\0' ]] && break
                        prompt='*'
                        PAWD+="$char"
                done
 echo ""
for i in `cat list.txt` ; do sshpass -p "${PAWD}" ssh -t -o StrictHostKeyChecking=no ${USAR}@$i "echo "-----------------------------------------------";uname -n;echo "------------------------------------";cat /opt/tivoli/tsm/client/ba/bin/dsm*.sys | grep -i server" >> /home/anmuthya/Desktop/1.txt ; done
unset PAWD
unset USAR

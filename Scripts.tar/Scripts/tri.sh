#!/bin/sh
echo "Hahaha"
while :
do 
amixer set Master unmute; amixer set Master 50%;aplay /home/anmuthya/Desktop/bond_theme.wav
done

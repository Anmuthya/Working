#!/bin/sh
read -p "enter your username - " USR
PAWD="" 

prompt=" > Input your password :"
                while IFS= read -p "$prompt" -r -s -n 1 char ;do
                        [[ $char == $'\0' ]] && break
                        prompt='*'
                        PAWD+="$char"
                done
echo ""
read -p "enter your command - " CAMD
for i in `cat list.txt` ; do sshpass -p "${PAWD}" ssh ${USR}@$i ${CAMD}; done
unset CAMD 
unset USR
unset PAWD












																







																																						#Maverick

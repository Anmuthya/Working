#!/bin/sh
if [[ "`uname -n`" == "USBLDPLP"* ]]; then
echo "----------This is a Production server, Be Careful !!!!-----------------"

elif [[ "`uname -n`" == "usbldplp"* ]]; then
echo "----------------------This is a Production server, Be Careful !!!!--------------- "

elif [[ "`uname -n`" == "usbldplt"* ]]; then
echo "----------This is a Test server-----------------"

elif [[ "`uname -n`" == "USBLDPLT"* ]]; then
echo "----------This is a Test server-----------------"

elif [[ "`uname -n`" == "USBLDLI"* ]]; then
echo "------IBM------"

else
echo "---------UNKNOWN-----------"
fi

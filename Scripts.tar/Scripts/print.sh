#!/usr/bin/bash
NOTIFY="anmuthya@in.ibm.com"
LOG=/tmp/printqueue.log
HOST=`uname -n`
for i in `cat /home/anmuthya/printqueue.txt`
do
lpstat -p$i | grep disabled > /tmp/prtqdown.txt
PRTC=`cat /tmp/prtqdown.txt|wc -l`
if [ $PRTC -gt 0 ]
then
echo "Print queue $i down, enablng the print queue" > /tmp/printqueue.log
cupsenable $i
sleep 3
echo " Now Print queue status  " >> /tmp/printqueue.log
echo " `lpstat -p$i` " >> /tmp/printqueue.log
mailx -s "${HOST} - Print queue restarted" $NOTIFY < $LOG
fi
done

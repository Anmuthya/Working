#!/usr/bin/python

print "Hello This is the sample Python example !!!"
name ='Hello this is the second one '
print name
list =['Kevin', '03666M','India',15000]
print list
print list[1:3]
print list*2
tuple =('abcd',123,'Hello')
print tuple
from Tkinter import *
master =Tk()
master.minsize(500,400)
def callback():
	print "click !"
b=Button(master,text="OK",command=callback,height=15,width=15)

b.pack()
mainloop()

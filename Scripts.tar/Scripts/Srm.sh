#!/bin/sh
uname -n;
cd /var/adm/perfmgr/bin && ./terminate.srm;
sleep 2;
cd /var/adm/perfmgr/bin && ./verify.srm;
/opt/samgr/bin/parity_ctrl status;
/opt/samgr/bin/parity_ctrl sa_comm stop;
/opt/samgr/bin/parity_ctrl hats.sa stop;
echo "sleep for 30 seconds..........";
sleep 30;
/opt/samgr/bin/parity_ctrl sa_comm start;
sleep 3;
/opt/samgr/bin/parity_ctrl hats.sa start;
sleep 2;
/opt/samgr/bin/parity_ctrl status;
echo "Done" 

echo "             *"
echo "            ***"
echo "           *****"
echo "          *******"
 

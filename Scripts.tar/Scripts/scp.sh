#!/bin/sh
read -p "Enter your username to be used on the server !!! -  " USER
PAWD="" 

prompt=" > Input your password :"
                while IFS= read -p "$prompt" -r -s -n 1 char ;do
                        [[ $char == $'\0' ]] && break
                        prompt='*'
                        PAWD+="$char"
                done
echo ""
read -p "Enter the source location - " SRC

for i in `cat list.txt` ; do sshpass -p "${PAWD}" scp -pr ${SRC} ${USER}@$i: ;echo $i ; done
unset PAWD
unset USER
unset SRC






	
																		#Maverick

#!/bin/sh
read -p "Enter your username to be used on the server !!! -  " USER
PAWD="" 

prompt=" > Input your password :"
                while IFS= read -p "$prompt" -r -s -n 1 char ;do
                        [[ $char == $'\0' ]] && break
                        prompt='*'
                        PAWD+="$char"
                done
for i in `cat list.txt` ; do sshpass -p "${PAWD}" ssh -t -o StrictHostKeyChecking=no ${USER}@$i "echo $PAWD|sudo -S
uname -n;sudo /var/adm/perfmgr/bin/terminate.srm;
sleep 2;
sudo /var/adm/perfmgr/bin/verify.srm;
sudo /opt/samgr/bin/parity_ctrl status;
sudo /opt/samgr/bin/parity_ctrl sa_comm stop;
sudo /opt/samgr/bin/parity_ctrl hats.sa stop;
echo "sleep for 30 seconds..........";
sleep 30 ;
sudo /opt/samgr/bin/parity_ctrl sa_comm start;
sudo /opt/samgr/bin/parity_ctrl hats.sa start;
sudo /opt/samgr/bin/parity_ctrl status;
echo "Done" " ; done


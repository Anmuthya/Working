#!/bin/sh
read -p "Enter your username to be used on the server !!!" USER
PAWD="" 
prompt=" > Input your password :"
                while IFS= read -p "$prompt" -r -s -n 1 char ;do
                        [[ $char == $'\0' ]] && break
                        prompt='*'
                        PAWD+="$char"
                done
echo ""
#read -p "Enter your Command To be executed on the servers ------>" COMND

for i in `cat list.txt` ; do sshpass -p "${PAWD}" ssh -t -o StrictHostKeyChecking=no ${USER}@$i "echo ${PAWD}|sudo -S cp /etc/shadow /home/anmuthya/'$i'.shadow;chmod 755 /home/anmuthya/*.shadow" ; done 
for i in `cat list.txt` ; do sshpass -p "${PAWD}" scp anmuthya@$i:/home/anmuthya/*.shadow /home/anmuthya/Desktop/Linux/PNA/shadow ; done
echo "--Scped--"
unset PAWD
unset USER

#!/bin/sh
mkdir /home/anmuthya/Desktop/Hello;


HOST='0.0.0.0'
USER='anmuthya'
PASSWD='1qaz2wsx'
CMD='mkdir /home/anmuthya/Desktop/Hellotap'

(
echo open "$HOST"
sleep 2
echo "$USER"
sleep 2
echo "$PASSWD"
sleep 2
echo "$CMD"
sleep 2
echo "exit"
) | telnet

#!/bin/sh

file="/home/anmuthya/Desktop/lssecfixes.txt"

if [ -r $file ];then
echo "File has read access"

else 
echo "File doesn't have read access"
fi

if [ -e $file ];then
echo "file exists"

else
echo "file does'nt exists"
fi


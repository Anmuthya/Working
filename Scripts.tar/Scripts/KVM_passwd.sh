#!/bin/bash
echo "**************CLOSE THE KVM*****************"
KVM=n
read -p "Have you closed the KVM(y/n)--?" KVM
PAWD=""
if [[ "$KVM" == "y" ]]; then 
prompt=" > Input your TP password :"
                while IFS= read -p "$prompt" -r -s -n 1 char ;do
                        [[ $char == $'\0' ]] && break
                        prompt='*'
                        PAWD+="$char"
                done
echo
#echo $PAWD|sudo -S yum install chntpw -y
echo "KVMs on the machine"
virsh -c qemu:///system list --all 
echo $PAWD|sudo -S mkdir /tmp/mount
read -p "Copy the KVM from the above list and paste--" KVMNAME
echo $PAWD|sudo -S guestmount -c qemu:///system -d ${KVMNAME} -m /dev/sda2 --rw /tmp/mount/
sleep 5
echo $PAWD|sudo -S chntpw -l /tmp/mount/Windows/System32/config/SAM
read -p "Copy the USER name from above and paste--" KVMUSER

#prompt=" "
 #               while IFS= read -p "$prompt" -r -s -n 1 char ;do
  #                      [[ $char == "" ]] && break
   #                     echo $PAWD|sudo -S chntpw -u ${KVMUSER} /tmp/mount/Windows/System32/config/SAM
    #                    
     #           done


echo $PAWD|sudo -S chntpw -u -v ${KVMUSER} /tmp/mount/Windows/System32/config/SAM
#echo $PAWD|sudo -S umount /tmp/mount
else 
echo "Close your KVM"
fi


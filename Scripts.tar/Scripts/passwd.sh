#!/bin/sh
read -p "Enter your id - " USAR
PAWD=""

prompt=" > Input your password :"
                while IFS= read -p "$prompt" -r -s -n 1 char ;do
                        [[ $char == $'\0' ]] && break
                        prompt='*'
                        PAWD+="$char"
                done
echo ""
for i in `cat list.txt` ; do sshpass -p "${PAWD}" ssh-t -o StrictHostKeyChecking=no ${USAR}@$i "echo ${PAWD}|sudo -S cat /etc/passwd |cut -d ":" -f 1,5;echo '$i'-info" ; done >> /home/anmuthya/Desktop/passwd.txt
unset USAR
unset PAWD

read -p "Enter value of a" A
read -p "Enter value of b" B
set sum =$(($A+$B))
echo $sum

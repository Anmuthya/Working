echo "-----------Backup for the configuration files----------"
echo "creating a directory as /tmp/Patching_2017"
mkdir /tmp/Patching_2017
mkdir /tmp/Patching_2017/ifcfg
cp /etc/passwd /tmp/Patching_2017/passwd_backup
cp /etc/hosts /tmp/Patching_2017/hosts_backup
cp /etc/group /tmp/Patching_2017/group_backup
cp /etc/fstab /tmp/Patching_2017/fstab_backup
cp /etc/sysconfig/network-scripts/ifcfg-* /tmp/Patching_2017/ifcfg/
cp /etc/shadow /tmp/Patching_2017/shadow_backup
uname -a > /tmp/Patching_2017/uname_backup
date >/tmp/Patching_2017/date_backup
netstat -nr >/tmp/Patching_2017/netstat_backup
chkconfig --list >/tmp/Patching_2017/chkconfig_backup
service --status-all >/tmp/Patching_2017/services_backup
cp /etc/exports /tmp/Patching_2017/exports_backup
df -PTh >/tmp/Patching_2017/filesystem_backup
ntpq -p > /tmp/Patching_2017/ntp
echo "Done!!!  you can find the backed up files in the /tmp/Patching_2017"

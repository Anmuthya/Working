#!/bin/sh
read -p "enter your username - " USR
PAWD="" 
PAWD2=""
prompt=" > Input your password :"
                while IFS= read -p "$prompt" -r -s -n 1 char ;do
                        [[ $char == $'\0' ]] && break
                        prompt='*'
                        PAWD+="$char"
                done
echo ""
prompt=" > Input your password on the network :"
                while IFS= read -p "$prompt" -r -s -n 1 char ;do
                        [[ $char == $'\0' ]] && break
                        prompt='*'
                        PAWD2+="$char"
                done
echo ""
read -p "enter your command - " CAMD
for i in `cat list.txt` ; do sshpass -p "${PAWD}" ssh anmuthya@10.30.5.250 ssh {USR}@$i ${CAMD}; done
unset CAMD 
unset USR
unset PAWD
unset PAWD2











																
